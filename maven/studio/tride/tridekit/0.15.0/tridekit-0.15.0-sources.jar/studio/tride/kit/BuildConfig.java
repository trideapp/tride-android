/**
 * Automatically generated file. DO NOT MODIFY
 */
package studio.tride.kit;

public final class BuildConfig {
  public static final boolean DEBUG = false;
  public static final String LIBRARY_PACKAGE_NAME = "studio.tride.kit";
  public static final String BUILD_TYPE = "release";
  // Field from default config.
  public static final String FILAMENT_VERSION = "1.77.1";
}
